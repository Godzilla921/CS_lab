# include "cachelab.h"
# include <stdio.h>
# include <stdlib.h>
# include <unistd.h>
# include <getopt.h>
typedef struct node1{
    int valid;
    int tag;
    int stamp;
}cache_line;

typedef struct node2{
    int s;
    int S;
    int E;
    int b;
    int hit;
    int miss;
    int eviction;
    cache_line **cache;
}Cache;

void initCache(Cache *myCache);
void clearCache(Cache *myCache);
void updateTime(Cache *mycache);
void updateCache(unsigned int address, Cache *myCache);

int verbose = 0;

int main(int argc, char **argv)
{
    Cache *myCache = (Cache *)malloc(sizeof(Cache));
    if(myCache == NULL){
        printf("myCache malloc wrong\n");
        exit(-1);
    }
    FILE *file = NULL;
    int para = 0;
    while((para = getopt(argc, argv, "vs:E:b:t:"))!=-1){
        switch(para){
            case 'v':
                verbose = 1;
                break;
            case 's':
                myCache->s = atoi(optarg);
                myCache->S = 1<< myCache->s;
                break;
            case 'E':
                myCache->E=atoi(optarg);
                break;
            case 'b':
                myCache->b=atoi(optarg);
                break;
            case 't':
                if((file=fopen(optarg, "r")) == NULL){
                    printf("Open file: %s wrong\n", optarg);		
                    exit(-1);
                }
                break;
            default :
                break;
        }
    }
    initCache(myCache);
    char operation;
	unsigned int address;
	int size;
    while(fscanf(file, " %c %x,%d", &operation, &address, &size) != EOF){
        if(verbose) printf("%c %x,%d", operation, address, size);
        switch (operation){
            case 'I':
                //updateCache(address, myCache);
                break;
            case 'M':
                updateCache(address, myCache);
                updateCache(address, myCache);
                break;
            case 'L':
                updateCache(address, myCache);
                break;
            case 'S':
                updateCache(address, myCache);
                break;
            default:
                break;
        }
        if(verbose) printf("\n");
        updateTime(myCache);
    }
    clearCache(myCache);
    fclose(file);
    printSummary(myCache->hit, myCache->miss, myCache->eviction);
    return 0;
}


void initCache(Cache *myCache){
    myCache->hit = 0;
    myCache->miss = 0;
    myCache->eviction = 0;
    myCache->cache = (cache_line **)malloc(sizeof(cache_line *)*myCache->S);
    for(int i=0; i<myCache->S; i++){
        myCache->cache[i]=(cache_line *)malloc(sizeof(cache_line)*myCache->E);
    }
    for(int i=0; i<myCache->S; i++){
        for(int j=0; j<myCache->E; j++){
            myCache->cache[i][j].valid = 0;
            myCache->cache[i][j].tag = 0;
            myCache->cache[i][j].stamp = 0;
        }
    }
    return ;
}

void clearCache(Cache *myCache){
    for(int i=0; i<myCache->S; i++){
        free(myCache->cache[i]);
    }
    free(myCache->cache);
    free(myCache);
}

void updateTime(Cache *mycache){
    for(int i=0 ;i<mycache->S; i++){
        for(int j=0; j<mycache->E; j++){
            if(mycache->cache[i][j].valid){
                mycache->cache[i][j].stamp++;
            }
        }
    }
}
void updateCache(unsigned int address, Cache *myCache){
    unsigned s_index =(address>>myCache->b) & ((0xffffffff)>>(32-myCache->s));
	unsigned tag = address>>(myCache->s+myCache->b);
    for(int j=0; j<myCache->E; j++){
        if(myCache->cache[s_index][j].valid&&myCache->cache[s_index][j].tag==tag){
            myCache->cache[s_index][j].stamp = 0;
            myCache->hit++;
            if(verbose) printf(" hit");
            return ;
        }
    }
    for(int j=0; j<myCache->E; j++){
        if(!myCache->cache[s_index][j].valid){
            myCache->cache[s_index][j].stamp=0;
            myCache->cache[s_index][j].valid=1;
            myCache->cache[s_index][j].tag=tag;
            myCache->miss++;
            if(verbose) printf(" miss");
            return ;
        }
    }
    int max_stamp = 0;
    int max_j=0;
    for(int j=0; j<myCache->E; j++){
        if(max_stamp < myCache->cache[s_index][j].stamp){
            max_stamp = myCache->cache[s_index][j].stamp;
            max_j = j;
        }
    }
    myCache->cache[s_index][max_j].stamp = 0;
    myCache->cache[s_index][max_j].tag = tag;
    myCache->cache[s_index][max_j].valid = 1;
    myCache->eviction ++;
    myCache->miss ++;
    if(verbose) printf(" miss eviction");
    return ;
}
